from django.apps import AppConfig


class ContentLicencingConfig(AppConfig):
    name = 'content_licencing'
